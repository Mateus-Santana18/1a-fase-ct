let inptProduto = document.getElementById("inptproduto")
let inptMarcaProduto = document.getElementById("inptmarcaProduto")
let inptValorProduto = document.getElementById("inptvalorProduto")

let vetorProdutos = []

// Function para cadastrar produto
function cadastroProdutos(){
    if(inptProduto.value == ""){

        document.getElementById("aparecerProdutos").innerHTML = ""
        document.getElementById("aparecerProdutos").innerHTML = "Cadastra um produto válido ai cara!!"

    }
    else if(inptProduto.value != "" && inptMarcaProduto.value == ""){

        document.getElementById("aparecerProdutos").innerHTML = ""
        document.getElementById("aparecerProdutos").innerHTML = "Coloca a marca do produto ai cara!!"

    }
    else if(inptProduto.value != "" && inptMarcaProduto.value != "" && inptValorProduto.value == ""){

        document.getElementById("aparecerProdutos").innerHTML = ""
        document.getElementById("aparecerProdutos").innerHTML = "Ta de graça? Coloca o preço ai né!!"

    }
    else{
    let lojaProdutos = {

        produto: '',
        marca: '',
        preco: 0,
        
    }

    lojaProdutos.produto = inptProduto.value
    lojaProdutos.marca = inptMarcaProduto.value
    lojaProdutos.preco = inptValorProduto.value

    vetorProdutos = JSON.parse(localStorage.getItem("produtosLoja"))

    if(vetorProdutos == null){

        vetorProdutos = []
        vetorProdutos.push(lojaProdutos)
        localStorage.setItem("produtosLoja", JSON.stringify(vetorProdutos))
        

    }else{

        vetorProdutos.push(lojaProdutos)
        localStorage.setItem("produtosLoja", JSON.stringify(vetorProdutos))
        

    }

    limparInpts()
    listarProdutos()
    alert("Produto cadastrado com sucesso!!!")
}
}

// Function assim que clicar no botão buscar vai aparecer todos os dados nos inputs do respectivo produto
// assim ficando mais facil para edita-lo ou exclui-lo
function procurarProdutos(){

    for(i=0; i < vetorProdutos.length; i++){

        if(inptProduto.value == vetorProdutos[i].produto){

            inptProduto.value = vetorProdutos[i].produto
            inptMarcaProduto.value = vetorProdutos[i].marca
            inptValorProduto.value = vetorProdutos[i].preco

        }

    }
    

}

// Function para aparecer a lista de produtos
function listarProdutos(){

    vetorProdutos = JSON.parse(localStorage.getItem("produtosLoja"))
    let listarProdutos = ""
    document.getElementById("aparecerProdutos").innerHTML = ""

    if(vetorProdutos == null){

        listarProdutos = "Nenhum Produto Cadastrado!!!!Cadastra ai :)"

    }else{

        for(i=0; i < vetorProdutos.length; i++){
    
            listarProdutos +=  Object.values(vetorProdutos[i]).join(' - ') + '<br>'
    
        }
        
    }
    
    document.getElementById("aparecerProdutos").innerHTML = listarProdutos  
    

}

// Function para editar o produto
function alterarProdutos(){
    vetorProdutos = JSON.parse(localStorage.getItem("produtosLoja"))
        if(inptProduto.value != '' && inptMarcaProduto.value != '' && inptValorProduto.value != ''){
        for(i = 0; i < vetorProdutos.length; i++){

            if(vetorProdutos[i].produto == inptProduto.value){
            vetorProdutos[i].produto = inptProduto.value
            vetorProdutos[i].marca = inptMarcaProduto.value
            vetorProdutos[i].preco = inptValorProduto.value
        }
        }

        localStorage.setItem("produtosLoja", JSON.stringify(vetorProdutos))
        alert("Dados atualizados!")
    }else{

        document.getElementById("aparecerProdutos").innerHTML = ""
        document.getElementById("aparecerProdutos").innerHTML = "Pra alterar precisa mudar algo válido né cabeça!!!!"
        
    }
    

}

// Function para deletar o produto pelo nome que você colocar no input
function deletarProdutos(){

    vetorProdutos = JSON.parse(localStorage.getItem("produtosLoja"))
    let posicaoExcluir
    
        
        for(i=0; i < vetorProdutos.length; i++){
    

          if(inptProduto.value == vetorProdutos[i].produto){
    
            posicaoExcluir = i
    
            vetorProdutos.splice(posicaoExcluir, 1)

            alert("Produto excluído!")
            
            localStorage.setItem("produtosLoja", JSON.stringify(vetorProdutos))
            
          }else{
            document.getElementById("aparecerProdutos").innerHTML = "Produto inválido amigão, me ajuda ai coloca certo!!" 
          }
    
        }
    
        
       limparInpts()
}



// Function para limpar os inputs
function limparInpts(){

    inptProduto.value = ""
    inptMarcaProduto.value = ""
    inptValorProduto.value = ""

}