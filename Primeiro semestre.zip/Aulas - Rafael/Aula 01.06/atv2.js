let maiorAltura = 0
let menorAltura = 99999
let altMasc = 0  
let altFem = 0
let masc = 0
let fem = 0
let pessoas = 4

for (let i = 0; i < pessoas; i++) {
   
    let numero = Number(prompt("Digite 0 para masculino e 1 para feminino: "))
    let altura = Number(prompt("Digite a altura da pessoa:"))
    
    if (numero == 0) {
        masc += 1
        altMasc += altura
    }else{
        fem += 1
        altFem += altura
    }

    if (altura > maiorAltura) {
        maiorAltura = altura
    }if (altura < menorAltura) {
        menorAltura = altura
    }
    }

    let mediaMulher = altFem / fem
    let mediaPop = (altFem + altMasc) / pessoas
    let mediaHomem = (100/pessoas) * masc

    alert(`A maior altura encontrada é ${maiorAltura.toFixed(2)} CM\nA menor altura encontrada é ${menorAltura.toFixed(2)} CM`)
    alert(`A média das alturas das mulheres é ${mediaMulher.toFixed(1)} CM \nO percentual de homens é ${mediaHomem}`)

