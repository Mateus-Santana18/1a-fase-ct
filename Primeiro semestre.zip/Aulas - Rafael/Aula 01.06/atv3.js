let valentina = 1.50
let enzo = 1.40
let anos = 0

do{
    enzo += 0.03
    valentina += 0.02
    anos += 1
}while (enzo <= valentina)
alert(`Serão necessários ${anos} anos, para enzo ser maior que valentina`)