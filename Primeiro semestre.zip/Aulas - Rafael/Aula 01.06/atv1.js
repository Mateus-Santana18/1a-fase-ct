
let somaImpares = 0
let multiplicacao = 1



for(i = 0; i < 6; i++){

    let numero = Number(prompt("Digite um número: "))
    
    if (numero % 2 == 1) {
        somaImpares += numero 
    }else{
        multiplicacao *= numero      
    }
}
alert(`A soma dos numeros ímpares é ${somaImpares} \n A multiplicação dos numeros pares é ${multiplicacao}`)