
function gerar() {
    let numero = Number(document.getElementById('inpNumero').value)
    let cont = 0

    while(cont < numero){
    
        cont++
        alert("Número" + cont)
        
    } 
   
}



function gerarDois() {
    let numeroDois = Number(document.getElementById('inptNumero').value)
    let contador = numeroDois
    
    while (contador >= 0) {
        
        alert("Número: " + contador)
        contador--
        
    }
    
}
