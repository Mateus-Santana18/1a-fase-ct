let resultado = document.getElementById('divResultado')

function consultar() {

    let cont = 0
    let preco = 0.33
    while (cont < 500) {
        
        cont++
        resultado.innerHTML += cont + " : R$" + (cont * preco).toFixed(2) + "<br>"
        
    }
    
}