let resultado = document.getElementById('divResultado')
let resultadoDois = document.getElementById('divResultadoDois')

function calcular() {
    let contUm = 10
    

    while (contUm <= 1000) {
        
            if (contUm <= 500) {
                resultado.innerHTML += contUm + "<br>" 
                
            }
            if (contUm  >= 900 ) {
                resultadoDois.innerHTML += contUm + "<br>" 
                
            }      
    
            contUm++
}

}