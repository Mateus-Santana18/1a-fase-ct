let resultado = document.getElementById('divResultado')

function gerar() {
    
    let cont = 1000

    while (cont <= 1999) {
        
        
        
        if (cont % 11 == 5) {
            resultado.innerHTML += "<br> Número:" + cont
        }
        cont++
    }


}