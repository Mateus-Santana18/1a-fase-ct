let resultado = document.getElementById('divResultado')

function calcular() {
    
    let cont = 0
    let numero = Number(document.getElementById('inptNumero').value)
    while(cont < 10){
        
        cont++
        resultado.innerHTML += numero + "x" + cont + " = " + (numero * cont) + "<br>"
        
    }
}

function limpar() {
    
    resultado.innerHTML = ""

}