let resultado = document.getElementById('divResultado')

let numeroMaior = 0
let numeroMenor = 99999

function gerar() {
    
    let cont = 0


    while (cont < 15) {
        let numero = Number(prompt("Digite um número"))
        cont++

        if (numero > numeroMaior ) {
            numeroMaior = numero
        }if (numero < numeroMenor) {
                numeroMenor = numero
            }
        }

        resultado.innerHTML = `Número maior ${numeroMaior}, Número menor ${numeroMenor}`

    }
    

