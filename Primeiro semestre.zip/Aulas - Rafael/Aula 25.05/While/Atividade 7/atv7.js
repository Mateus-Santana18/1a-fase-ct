let resultado = document.getElementById('divResultado')
let acabei = document.getElementById('acabou')
function contar() {
    let cont = 0
    while (cont < 250) {
        cont++
        resultado.innerHTML += cont + "<br>"  
        acabei.innerHTML = "MANHÊ, ACABEI O PRIMEIRO"
    }
        
}
function contarCem() {
    let contUm = 250

    while (contUm >= 100) { 
        resultado.innerHTML += contUm + "<br>"
        contUm--
        acabei.innerHTML = "MANHÊ, ACABEI O SEGUNDO"
    }
}
function contarCinco() {
    
    let contDois = 100

    while (contDois >= 0) {
        resultado.innerHTML += contDois + "<br>"
        contDois = contDois - 5
        acabei.innerHTML = "MANHÊ, ACABEI O TERCEIRO"
    }
}
function contarTres() {
    
    let cont = 0

    while (cont < 9500) {
        resultado.innerHTML += cont + "<br>"
        cont = cont + 3
        acabei.innerHTML = "MANHÊ, ACABEI O QUARTO"
    }
}
function contarPar() {
    
    let contTres = 9500

    while(contTres < 9600){
        contTres++
        if (contTres % 2 == 0) {
            resultado.innerHTML += contTres + "<br>"
            acabei.innerHTML = "MANHÊ, ACABEI MAIS UM"
        }
    }
}
function contarImpar() {
    let contQuatro = 9600

    while(contQuatro < 10285){
        contQuatro++
        if (contQuatro % 2 == 1) {
            resultado.innerHTML += contQuatro + "<br>"
            acabei.innerHTML = "MANHÊ, ACABEI TUDOOO. POSSO JOGAR BOLA?"
        }
    }
}
