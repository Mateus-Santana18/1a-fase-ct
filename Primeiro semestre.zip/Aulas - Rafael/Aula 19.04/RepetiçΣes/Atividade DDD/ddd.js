function Enviar() {
    


let destination 

let ddd = Number(prompt('Digite o DDD'))

switch (ddd) {
    case 61:
        destination = 'Brasilia'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 71:
        destination = 'Salvador'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 11:
        destination = 'São Paulo'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 21:
        destination = 'Rio de janeiro'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 32:
        destination = 'Juiz de fora'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 19:
        destination = 'Campinas'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 27:
        destination = 'Vitória'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    case 31:
        destination = 'Belo Horizonte'
        alert(`O DDD digitado foi ${ddd} da cidade de ${destination}`)
        break;
    default:
            alert("DDD inválido!!!")
        break;

}
}
