function calcular() {
    



let codigo = Number(prompt("Código:"))
let quantidade = Number(prompt("Quantidade:"))
let precoUnitario 
let total

switch (codigo) {
    case 1:
            precoUnitario = 4
        break;
    case 2:
            precoUnitario = 4.5
        break;
    case 3:
            precoUnitario = 5
        break;
    case 4:
            precoUnitario = 2
        break;
    case 5:
            precoUnitario = 1.5
        break;

    default:
        break;
}


total = precoUnitario * quantidade

alert("Valor total: R$" + total.toFixed(2))
}



// let calculo1,calculo2,calculo3,calculo4,calculo5,calculoFinal

// let cachorroQ //= Number(prompt("Digite quantos cachorros quentes deseja:"))
// let xSalada //= Number(prompt("Digite quantos X-saladas deseja: "))
// let xBacon //= Number(prompt("Digite quantos X-bacon deseja: "))
// let torrada //= Number(prompt("Digite quantas torradas deseja: "))
// let refri //= Number(prompt("Digite quantos refrigerantes deseja:"))

// calculo1 = calculo1 + cachorroQ * 4

// calculo2 = calculo2 + xSalada *  4.5

// calculo3 = calculo3 + xBacon * 5

// calculo4 = calculo4 + torrada * 2

// calculo5 = calculo5 + refri * 1.50

// calculoFinal = calculo1 + calculo2 + calculo3 + calculo4 + calculo5