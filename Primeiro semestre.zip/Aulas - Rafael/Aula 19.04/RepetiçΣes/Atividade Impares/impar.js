    let i = Number(prompt('Digite um número:'))

    for(let i = 0; i ; i++){
        if(i % 2 == 1){
            console.log(i); 
        }   
    }

   