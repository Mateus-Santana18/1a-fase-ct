
let idade  //Number(prompt("Digite a sua idade: "))

// while (idade < 0 ) {
//     idade = Number(prompt("Idade inválida!!"))
// while (idade > 130) {
//     idade = Number(prompt("Idade inválida"))
// }
// }

// alert("Idade válida!!")

// do {
//     idade = Number(prompt("Sua idade: "))
// } while (idade < 0)

// alert("Idade válida" + idade + "Anos")

for(i = 0; i < 100 ; i++){
    if (i % 2 == 0) {
        console.log(i);    
    }
    
}
