let resultado = document.getElementById('divResultado')
let quantAlcool = 0
let quantGasolina = 0
let quantDiesel = 0

function calcular(){
let preference = document.getElementById('valor').value

  
if(preference == "1"){
    quantAlcool += 1
    resultado.innerHTML = ""
}else{
    if(preference == "2"){
        quantGasolina += 1
        resultado.innerHTML = ""
    }else{
        if(preference == "3"){
            quantDiesel += 1
            resultado.innerHTML = ""
        }else{
            if(preference == "4"){
                resultado.innerHTML = `Muito obrigado!!! a quantidade de Alcool foi ${quantAlcool}, a quantidade de Gasolina foi ${quantGasolina} e a de diesel foi ${quantDiesel}`
                quantAlcool = 0
                quantGasolina = 0
                quantDiesel = 0
            }else{
                resultado.innerHTML = "Insira um código válido"
            }
        }
    }
}

    
    
    }
