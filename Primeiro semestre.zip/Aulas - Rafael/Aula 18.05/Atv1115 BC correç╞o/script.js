
let resultado = document.getElementById('divResultado')

function acharQuadrante(){


let x = Number(document.getElementById('valorUm').value)
let y = Number(document.getElementById('valorDois').value)


if (x > 0 && y > 0){
    resultado.innerHTML = "Quadrante 1"   
}else{
    if (x < 0 && y > 0) {
        resultado.innerHTML = "Quadrante 2"
    }else{
        if(x < 0 && y < 0){
            resultado.innerHTML = "Quadrante 3"
        }else{
            if(x > 0 && y < 0){
                resultado.innerHTML = "Quadrante 4"
            }else{
                resultado.innerHTML = "Insira um valor válido"
            }
        }
    }
}
}