let resultado = document.getElementById('divResultado')
function calcularMedia(){

let numeroUm = Number(document.getElementById('valorUm').value)
let numeroDois = Number(document.getElementById('valorDois').value)

if(numeroUm >= 0 && numeroUm <= 10 && numeroDois >= 0 && numeroDois <= 10){
    let media = ( numeroUm + numeroDois ) / 2
    resultado.innerHTML = 'Média: ' + media
}else{
    alert("As notas não são válidas. Insira uma nota válida")
}

}