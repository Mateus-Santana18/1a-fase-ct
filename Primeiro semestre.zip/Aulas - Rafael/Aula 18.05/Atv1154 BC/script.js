let idade = Number(prompt('Digite uma idade'));

let soma = 0;
let contador = 0;

while (idade >= 0){
    idade = Number(prompt('Digite uma idade:'));
    
        
        soma = soma + idade
        contador++;
}   

let media = soma / contador
console.log(media.toFixed(2));
