let pessoas = []

// let pessoa = {
//     nome: 'fulaninho',
//     idade: 43
// }

// pessoas.push(pessoa)

function cadastrar(){
    let pessoa = {
    nome: document.getElementById("nome").value,
    idade: Number(document.getElementById("numero").value)
    }

    pessoas.push(pessoa)
}