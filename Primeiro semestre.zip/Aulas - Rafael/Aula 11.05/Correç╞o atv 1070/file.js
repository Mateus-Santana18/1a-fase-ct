    
    let numero = document.getElementById('inptNumero')
    let resultado = document.getElementById('divResultado')

function Gerar(){
    n = Number(numero.value)
    
    
    resultado.innerHTML = ""

    

    if(n % 2 == 0){
        n++;
    }

    let contImpares = 0
    while (contImpares < 6) {
        resultado.innerHTML += n + "<br>"
        contImpares++
        n = n + 2
    }

}