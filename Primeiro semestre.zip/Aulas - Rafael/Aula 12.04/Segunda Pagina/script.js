let nota1,nota2,nota3,media

nota1 = Number(prompt("Digite a sua primeira nota: "))
nota2 = Number(prompt("Digite a sua segunda nota: "))
media = (nota1+nota2) / 2


alert(media)

if (media >= 7) {
  alert("Aprovado!!!")
  document.write("Aprovado!!!")
} else {
  alert("Reprovado!!!") 
  document.write("Reprovado!!!") 
}