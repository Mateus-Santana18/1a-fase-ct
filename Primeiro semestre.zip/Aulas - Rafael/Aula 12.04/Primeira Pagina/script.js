let saldoEspino = 0
//let doacaoEspino 
let saldoEstego = 0
//let doacaoEstego
let saldoRex = 100000

function doarParaEspinossauro(){
    //doacaoEspino = Number(prompt("Digite o quando você quer doar: R$"))
    saldoEspino = saldoEspino + 500
    alert("Total arrecadado: R$" + saldoEspino.toFixed(2))
}
function doarParaEstegossauro(){
    //doacaoEstego = Number(prompt("Digite o quando você quer doar: R$"))
    saldoEstego = saldoEstego + 250
    alert("Total arrecadado: R$" + saldoEstego.toFixed(2))
}
function socializarDinheiro(){
    saldoRex = saldoRex - 750  // Retirar 750 do rex
    saldoEspino = saldoEspino + 500  // Doar 500 pro espino
    saldoEstego = saldoEstego + 250  // Doar 250 pro estego
    alert("Espino: R$" + saldoEspino.toFixed(2)+ "\nRex: R$" + saldoRex + "\nEstego: R$" + saldoEstego.toFixed(2))  // Mostrar os 3 saldos
    
    
    
}