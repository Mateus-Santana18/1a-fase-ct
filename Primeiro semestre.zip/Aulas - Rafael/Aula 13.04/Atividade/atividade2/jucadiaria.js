let diaria = Number(prompt("Digite quantos dias vai ficar no albergue: "))
let diariaCalculo 
let desconto
let valortotal
let multa = 150
let valorDiaria

if (diaria <= 5) {
    valorDiaria = 100
}else{
    if(diaria >= 6 && diaria <= 10){
        valorDiaria = 90
        
    }else{
       valorDiaria = 80 
    }

}

diariaCalculo = valorDiaria * diaria
desconto = diariaCalculo * 25 / 100
valortotal = diariaCalculo + multa - desconto
alert('O total das diárias é: ' + valortotal)