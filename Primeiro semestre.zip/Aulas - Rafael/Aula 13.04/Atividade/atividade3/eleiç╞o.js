let idade = Number(prompt("Digite a sua idade: "))

if(idade < 16 && idade > 0 ){
    alert("Não pode votar!!")
}else{
    if(idade == 16 || idade == 17 || idade > 65){
        alert("Voto facultativo!!")
    }else{
        if(idade >= 18 && idade <= 65){
            alert("Voto obrigatório!!")
        }else{
            alert("Para de mentir a idade!!!")
        }
    }
}