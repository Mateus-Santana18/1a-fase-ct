let pontuacao = Number(prompt("Digite sua pontuação: "))


if (pontuacao <= 10) {
    console.log('Patinho');
} else {
    if (pontuacao > 10 && pontuacao <= 100) {
        console.log('Tá, melhora ai o patinho!')
    } else {
        if (pontuacao > 100 && pontuacao <= 200) {
            console.log('Supimpa');
        } else {
            console.log('Mitou');
        }
    }
}



