let pontuacao = Number(prompt("Digite sua pontuação: "))


if (pontuacao <= 10) {
    console.log('Patinho');
}
if (pontuacao > 10 && pontuacao <= 100) {
    console.log('Tá, melhora ai o patinho!');
}
if (pontuacao > 100 && pontuacao <= 200) {
    console.log('Supimpa');
}
if (pontuacao > 200) {
    console.log('Mitou');
}

