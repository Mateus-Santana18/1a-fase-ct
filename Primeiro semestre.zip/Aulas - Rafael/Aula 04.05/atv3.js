let notaUm = Number(prompt('Digite sua nota:'))

if(notaUm < 0 || notaUm > 10){
    console.log('Nota invalida!!');
}else{
    let notaDois = Number(prompt('Digite sua segunda nota'))
 if(notaDois < 0 || notaDois > 10){
    console.log('Nota invalida!!');
}else{
    let media = (notaUm + notaDois) / 2
console.log(media);
}
}




// if(notaUm >= 0 && notaUm <= 10 && notaDois >= 0 && notaDois <= 10){
//     let media = (notaUm + notaDois) / 2
//     console.log(`Média ${media.toFixed(2)}`);
// }else{
//     console.log('Nota inválida');
// }


