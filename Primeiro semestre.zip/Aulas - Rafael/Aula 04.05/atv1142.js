let pergunta = Number(prompt('Digite quantas vezes você quer: '))


let valorFinal = 0;
for (let index = 0; index < pergunta; index++) {
    for (let index = 1; index <= 4; index++) {
        valorFinal += 1;
    }
    console.log(valorFinal - 3, valorFinal - 2, valorFinal - 1, 'pum');
}
