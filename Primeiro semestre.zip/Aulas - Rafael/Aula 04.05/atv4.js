let preference = prompt('Digite qual sua preferência:')


let quantAlcool = 0
let quantGasolina = 0
let quantDiesel = 0

let continueWhile = true

while (continueWhile) {
    if (preference == "1") {
        quantAlcool += 1
    }
    if (preference == "2") {
        quantGasolina += 1
    }
    if (preference == "3") {
        quantDiesel += 1
    }
    if (preference == "4") {
        console.log("Muito Obrigado!!!");
        continueWhile = false
        break;
    }
    preference = prompt('Digite qual sua preferência:')
}
console.log(`Alcool: ${quantAlcool}`);
console.log(`Gasolina: ${quantGasolina}`);
console.log(`Diesel: ${quantDiesel}`);