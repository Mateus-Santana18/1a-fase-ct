let maior = 0
let maiorPos 

for(i = 1; i <= 100; i++){
    
    let porrinha = Math.floor(Math.random() * 1000)
    console.log(porrinha);

    if (porrinha >  maior) {
        maior = porrinha
        maiorPos = i
    }
    
}
alert(maior)
alert(maiorPos)