


let x = prompt('Digite a cordenada X')
let y = prompt('Digite a cordenada Y')

if (x > 0 && y > 0) {
    alert('Quadrante 1')
}else if(x < 0 && y > 0){
    alert('Quadrante 2')
}else if(x < 0 && y < 0){
    alert('Quadrante 3')
}else{
    alert('Quadrante 4')
}