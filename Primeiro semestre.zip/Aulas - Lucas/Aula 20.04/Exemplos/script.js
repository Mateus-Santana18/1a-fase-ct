// let valorInput = document.getElementById("inpt")
// let resInput = document.getElementById("inptRes")

// function Cadastro() {
    
//  resInput.value = valorInput.value

// }

let valorInputUm = document.getElementById("inptUm")
let valorInputDois = document.getElementById("inptDois")
let resInput = document.getElementById("inptRes")


function Cadastro(){
    
    resInput.value = Number(valorInputUm.value) + Number(valorInputDois.value)

}