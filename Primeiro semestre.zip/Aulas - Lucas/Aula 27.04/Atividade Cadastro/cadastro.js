
let usuario = document.getElementById('user')
let senha = document.getElementById('senha')
let endereco = document.getElementById('endereco')
let cidade = document.getElementById('cidade')

function cadastroCancelado() {
    
 alert('Cadastro Cancelado')


}

function cadastroConcluido() {
      
alert('Cadastro concluido com sucesso')
    
}