

alert("Boas vindas ao quiz na temática do POP, esse quiz funciona da seguinte forma, serão 4 perguntas e conforme sua resposta você vai ganhando pontos!!!Boa sorte!!!!")

let somaSerie,somaLivro,somaFranquia,somaAutor
let soma


let serieQuiz = prompt("Digite Quais séries a seguir englobam melhor a temática de vampiros e assombração de acordo com a letra:\nA) Van Helsing\nB) Castlevania\nC) The Vampire Diaries\nD) Blade: The Series ").toLowerCase()

switch(serieQuiz){

    case "a":
        somaSerie = 2
        alert(`Sua pontuação atual é ${somaSerie}`)
    break
    case "b":
        somaSerie = 3
        alert(`Sua pontuação atual é ${somaSerie}`)
    break
    case "c":
       somaSerie = 2
       alert(`Sua pontuação atual é ${somaSerie}`)
    break
    case "d":
        somaSerie = 1
        alert(`Sua pontuação atual é ${somaSerie}`)
    break
    default:
        somaSerie = 0
        alert(`Você fez 0 pontos nessa`)
    break
        
}

let livroQuiz = prompt("Dentre os livros abaixo, quais incluem melhor a temática de fantasia de acordo com a letra:\nA) Alice no País das Maravilhas\nB) O Hobbit\nC) A Fantástica Fábrica de Chocolates\nD) Coraline ").toLowerCase()

switch(livroQuiz){

    case "a":
        somaLivro = 4
        alert(`Sua pontuação atual é ${somaLivro + somaSerie}`)
    break
    case "b":
        somaLivro = 2
        alert(`Sua pontuação atual é ${somaLivro + somaSerie}`)
    break
    case "c":
        somaLivro = 4
        alert(`Sua pontuação atual é ${somaLivro + somaSerie}`)
    break
    case "d": 
        somaLivro = 3
        alert(`Sua pontuação atual é ${somaLivro + somaSerie}`)
    break
    default:
        somaLivro = 0
        alert(`Você fez 0 pontos nessa, sua pontuação atual é ${somaLivro + somaSerie}`)
    break

}

let franquiaQuiz = prompt("Quais das franquias listadas, representam melhor a empresa de jogos Nintendo de acordo com a letra:\nA) The Legend of Zelda\nB) Kirby\nC) Metroid\nD) Super Mario Bros").toLowerCase()

switch(franquiaQuiz){

    case "a":
        somaFranquia = 3
        alert(`Sua pontuação atual é ${somaFranquia + somaLivro + somaSerie}`)
    break
    case "b":
        somaFranquia = 2
        alert(`Sua pontuação atual é ${somaFranquia + somaLivro + somaSerie}`)
    break
    case "c":
        somaFranquia = 2
        alert(`Sua pontuação atual é ${somaFranquia + somaLivro + somaSerie}`)
    break
    case "d":
        somaFranquia = 4
        alert(`Sua pontuação atual é ${somaFranquia + somaLivro + somaSerie}`)
    break
    default:
        somaFranquia = 0
        alert(`Você fez 0 pontos nessa, sua pontuação atual é ${somaFranquia + somaLivro + somaSerie}`)
    break

}

let autorQuiz = prompt("Quais dos autores citados, representam melhor o gênero de livros de terror de acordo com a letra:\nA) Stephen King\nB) Edgar Allan Poe\nC) H.P. Lovecraft\nD) Mary Shelley ").toLowerCase()

switch(autorQuiz){

    case "a":
        somaAutor = 4
        
    break
    case "b":
        somaAutor = 2
        
    break
    case "c":
        somaAutor = 3
        
    break
    case "d":
        somaAutor = 4
        
    break
    default:
        somaAutor = 0
        alert(`Você fez 0 pontos nessa`)
    break

}

let pontuacaoTotal = somaSerie + somaLivro + somaFranquia + somaAutor

if (pontuacaoTotal == 15){

    alert(`Sua pontuação total foi ${pontuacaoTotal}, Parabéns!!!`)
}else{
    alert(`Sua pontuação total foi  ${pontuacaoTotal}`)
}
 