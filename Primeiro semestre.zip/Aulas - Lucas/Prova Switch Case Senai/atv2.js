let produto = prompt("Digite o produto comprado: ")
let qualidadeProduto = Number(prompt("Digite sua nota para a qualidade do produto:"))
let custoBeneficio  = Number(prompt("Digite sua nota para custo benefício do produto: "))
let durabilidadeProduto = Number(prompt("Digite sua nota para a durabilidade do produto:"))

let indiceProduto = (qualidadeProduto + custoBeneficio + durabilidadeProduto) / 3

switch(true){

    case indiceProduto < 5:
        alert(`Seu produto não ganhou destaque, seu índice foi ${indiceProduto.toFixed(2)} `)
    break
    case indiceProduto >= 5 && indiceProduto < 7:
        alert(`Seu produto ganhou destaque na página de categoria, seu índice foi ${indiceProduto.toFixed(2)}`)
    break
    case indiceProduto >= 7 && indiceProduto <= 9:
        alert(`Seu produto ganhou destaque na página de promoções, seu índice foi ${indiceProduto.toFixed(2)}`)
    break
    default:
        alert(`Seu produto ganhou destaque na página principal, seu índice foi ${indiceProduto.toFixed(2)}`)
    break
}
