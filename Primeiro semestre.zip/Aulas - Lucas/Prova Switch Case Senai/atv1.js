let nome  = prompt('Digite seu nome:')
let idade = Number(prompt('Digite sua idade:'))
let formacao = prompt('Digite sua formação:').toLowerCase()
let cidade = prompt('Digite sua cidade').toLowerCase()

if (idade >= 25 && idade <= 50 && formacao == "biologia" || formacao == "ecologia" && cidade == "florianópolis") {
    alert(`${nome}, você está apto para concorrer a vaga para equipe de resgate`)
}else if(idade >= 22 && idade <= 60 && formacao == "veterinaria" && cidade == "florianopolis"){
    alert(`${nome}, você está apto para concorrer a vaga para equipe de tratamento`)
}else{
    alert(`${nome}, você não está apto para concorrer a nenhuma vaga!!!`)
}