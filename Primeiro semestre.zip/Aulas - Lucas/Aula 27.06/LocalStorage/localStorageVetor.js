let users = []
let userAdd

    userAdd = prompt("Nome de usuário para adicionar: ")

    users = JSON.parse(localStorage.getItem('Usuarios'))

    alert(users)

    if(users == null){

        users = []
        users.push(userAdd)
        
    }else{

        users.push(userAdd)
        
    }

    localStorage.setItem('Usuarios', JSON.stringify(users))