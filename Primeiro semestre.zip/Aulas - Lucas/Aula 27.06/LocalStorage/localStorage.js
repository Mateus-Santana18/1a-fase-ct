let nome,idade
let nomeSalvo, idadeSalva

    nome = prompt("Digite o seu nome: ")
    idade = Number(prompt("Digite a sua idade: "))

    localStorage.setItem('Nome', nome)
    localStorage.setItem('Idade', idade)

    
    alert("Dados salvos!!")
    
    nomeSalvo = localStorage.getItem('Nome')
    idadeSalva = localStorage.getItem('Idade')

    console.log(nomeSalvo);
    console.log(idade);

    alert(`Dados trazidos do armazenamento:\n\nNome: ${nomeSalvo}\nIdade: ${idadeSalva}`)



// localStorage.setItem('Numero' , 15)
// localStorage.setItem('Nome', 'Abgail')

