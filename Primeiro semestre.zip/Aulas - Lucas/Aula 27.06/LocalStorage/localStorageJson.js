let nome,idade
let nomeSalvo, idadeSalva

    nome = prompt("Digite o seu nome: ")
    idade = Number(prompt("Digite a sua idade: "))

    localStorage.setItem('Nome', JSON.stringify(nome))
    localStorage.setItem('Idade', JSON.stringify(idade))

    
    alert("Dados salvos!!")
    
    nomeSalvo = JSON.parse(localStorage.getItem('Nome'))
    idadeSalva = JSON.parse(localStorage.getItem('Idade'))

    console.log(nomeSalvo);
    console.log(idade);

    alert(`Dados trazidos do armazenamento:\n\nNome: ${nomeSalvo}\nIdade: ${idadeSalva}`)





