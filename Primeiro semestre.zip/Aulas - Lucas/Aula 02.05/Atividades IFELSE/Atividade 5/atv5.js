let altura = document.getElementById('alturaCliente')
let peso = document.getElementById('pesoCliente')
let divResultado = document.getElementById('resultado')
let calculo

function verificar() {
    
    calculo = (Number(peso.value) / (Number(altura.value) * Number(altura.value))).toFixed(1)

    if(calculo < 18){
        divResultado.innerHTML = `IMC ${calculo} está abaixo do peso`
    }else if(calculo >= 18 && calculo <= 25){
        divResultado.innerHTML = `IMC ${calculo} está no peso ideal`
    }else{
        divResultado.innerHTML = `IMC ${calculo} está acima do peso`
    }



}
