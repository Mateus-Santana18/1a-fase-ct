let nome = document.getElementById('nomeCliente')
let idade = document.getElementById('idadeCliente')
let comorbidade = document.getElementById('comorbidade')
let divResultado = document.getElementById('resultado')
let comorbS = document.getElementById('select')




function verificar() {
    
    if (idade.value >= 60 || comorbS. == ) {
        divResultado.innerHTML = "Pode se vacinar!!!"
    }else{
        divResultado.innerHTML = "Não pode se vacinar!!!"
    }

}

