let divResultado = document.getElementById('resultado')

function Calcular() {
    let totalHabitantes = document.getElementById('habitantes')
    let areaTotal = document.getElementById('area')


    let calculo = Number(totalHabitantes.value) / Number(areaTotal.value)

    if (calculo >= 100) {
        divResultado.innerHTML =  "Densidade alta"
    }else if(calculo < 100 && calculo >= 25){
        divResultado.innerHTML = "Densidade média"
    }else{
        divResultado.innerHTML = "Densidade Baixa"
    }
}