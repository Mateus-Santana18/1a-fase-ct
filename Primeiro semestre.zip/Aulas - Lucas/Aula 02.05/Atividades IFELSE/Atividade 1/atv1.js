let primeiraNota = document.getElementById('notaUm')
let segundaNota = document.getElementById('notaDois')
let terceiraNota = document.getElementById('notaTres')
let quartaNota = document.getElementById('notaQuatro')
let resultado = document.getElementById('resultado')

function Calcular() {
let media = ((Number(primeiraNota.value) + Number(segundaNota.value) + Number(terceiraNota.value) + Number(quartaNota.value)) / 4).toFixed(1)
   

    if (media >= 7) {
         resultado.innerHTML = `Aprovado, sua média foi ${media}`
    }else if (media < 7 && media >= 5){
        resultado.innerHTML = `Recuperação, sua média foi ${media}`
    }else{
        resultado.innerHTML = `Reprovado, sua média foi ${media}`
    }

    
}
