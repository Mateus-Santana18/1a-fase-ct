function Entrar() {
    let usuario = document.getElementById('user')
    let senha = document.getElementById('senha')
    

    if (usuario.value == "admin" && senha.value == "123") {
        alert('Login efetuado!!!')
    }else{
        if(usuario.value != 'admin' && senha.value == "123"){
            alert('Usuário inválido!!!')
        }else if(usuario.value == 'admin' && senha.value != "123"){
            alert('Senha inválida!!!')
        }else{
            alert('Usuário e senha inválidos!!!')
        }
    }
    
}