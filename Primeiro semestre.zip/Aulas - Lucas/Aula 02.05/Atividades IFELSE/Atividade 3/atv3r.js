let nome = document.getElementById('nomeCliente')
let idade = document.getElementById('idadeCliente')
let divResultado = document.getElementById('resultado')
let comorbSim = document.getElementById('S')
let comorbNao = document.getElementById('N')



function verificar() {
    
    if (idade.value >= 60  || comorbSim.checked ) {
        divResultado.innerHTML = "Pode se vacinar!!!"
    }else{
        divResultado.innerHTML = "Não pode se vacinar!!!"
    }

}


