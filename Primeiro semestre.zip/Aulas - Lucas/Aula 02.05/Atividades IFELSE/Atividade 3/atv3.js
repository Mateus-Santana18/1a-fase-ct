let nome = document.getElementById('nomeCliente')
let idade = document.getElementById('idadeCliente')
let comorbidade = document.getElementById('comorbidade')
let divResultado = document.getElementById('resultado')



function verificar() {
    
    if (idade.value >= 60 || comorbidade.value == ("Sim").toLowerCase()) {
        divResultado.innerHTML = "Pode se vacinar!!!"
    }else{
        divResultado.innerHTML = "Não pode se vacinar!!!"
    }

}



