let salarioAnual = document.getElementById('salarioAno')
let pisoSalarial = document.getElementById('pisoSalario')
let resultado = document.getElementById('resultado')


function Verificar() {

    let salarioMensal = Number(salarioAnual.value / 12)

    if (salarioMensal > pisoSalarial.value){
        resultado.innerHTML = `Acima do piso salarial, seu salário é  ${salarioMensal.toFixed(2)}`
    }else if(salarioMensal == pisoSalarial.value){
        resultado.innerHTML = `Igual ao piso salarial, seu salário é ${salarioMensal.toFixed(2)}`
    }else{
        resultado.innerHTML = `Abaixo do piso salarial, seu salário é  ${salarioMensal.toFixed(2)}`
    }


}