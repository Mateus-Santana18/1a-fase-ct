function verificar() {
    let especie = document.getElementById('nomeEspecie')
    let populacao = document.getElementById('populacaoEspecie')
    let divResultado = document.getElementById('resultado')


    if (populacao.value >= 200 && populacao.value < 500) {
        divResultado.innerHTML = 'Espécie criticamente em perigo'
    }else if(populacao.value >= 500 && populacao.value < 1000){
        divResultado.innerHTML = 'Espécie em perigo'
    }else if(populacao.value >= 1000 && populacao.value <= 5000){
        divResultado.innerHTML = 'Espécie vulnerável!'
    }else{
        divResultado.innerHTML = 'Não está em extinção'
    }
}