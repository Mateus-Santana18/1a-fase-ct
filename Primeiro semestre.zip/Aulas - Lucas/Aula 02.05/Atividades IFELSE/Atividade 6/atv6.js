function verificar() {
    const idadeUm = document.getElementById('idadeUm');
    const idadeDois = document.getElementById('idadeDois');
    const idadeTres = document.getElementById('idadeTres');
    const idadeQuatro = document.getElementById('idadeQuatro');
    const idadeCinco = document.getElementById('idadeCinco');
    const divResultado = document.getElementById('resultado');  
    let mediaIdades =
        (Number(idadeUm.value) + Number(idadeDois.value) + Number(idadeTres.value) + Number(idadeQuatro.value) + 
    Number(idadeCinco.value)) / 5

    let maiorIdade = Number(idadeUm.value);
    
    if(Number(idadeDois.value) >= maiorIdade){
        maiorIdade = Number(idadeDois.value)
    }
    if(Number(idadeTres.value) >= maiorIdade){
        maiorIdade = Number(idadeTres.value)
    }
    if(Number(idadeQuatro.value) >= maiorIdade){
        maiorIdade = Number(idadeQuatro.value)
    }
    if(Number(idadeCinco.value) >= maiorIdade){
        maiorIdade = Number(idadeCinco.value)
    }

    // const listaIdades = Array.from(document.querySelectorAll('.inputIdade')).map(e => Number(e.value));

    // let maiorIdade = listaIdades[0];
    // for (let i = 1; i < listaIdades.length; i++) {
    //     if (listaIdades[i] > maiorIdade) {
    //         maiorIdade = listaIdades[i];
    //     }
    // }
    // const mediaIdades = listaIdades.reduce((acc, cv) => acc + cv) / listaIdades.length;
    divResultado.innerHTML = `A maior idade é ${maiorIdade} anos, e a média das idades é ${mediaIdades} anos.`
}

    
