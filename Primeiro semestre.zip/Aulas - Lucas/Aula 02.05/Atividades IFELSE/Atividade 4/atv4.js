let numero = document.getElementById('numeroInserido')
let divResultado = document.getElementById('resultado')


function verificar() {
    
    
    if (Number(numero.value) % 2 == 0) {
        divResultado.innerHTML = `O numero ${numero.value} é par`
    }else{
        divResultado.innerHTML = `O numero ${numero.value} é impar`
    }


}