let nome = prompt('Digite o nome do atleta:')
let idade = Number(prompt('Digite a idade do atleta:'))

switch (true) {
    case idade >= 5 && idade <= 10:
        alert("Categoria Infantil")
    break;
    case idade >= 11 && idade <= 15:
        alert("Categoria Juvenil")
    break;
    case idade >= 16 && idade <= 20:
        alert("Categoria Junior")
    break;
    case idade >= 21 && idade <= 25:
        alert("Categoria Profissional")
    break;
    default:
        alert("Insira uma data válida para consultar a categoria!!")
    break;
}