console.log('100 Cachorro Quente');
console.log('101 Bauru Simples ');
console.log('102 Bauru com Ovos');
console.log('103 Hamburguer');
console.log('104 Cheeseburguer');
console.log('105 Refrigerante ');

let codigo = prompt("Digite o código que você deseja:")
let quant = Number(prompt("Digite a quantidade:"))
let calculo

switch (codigo) {
    case "100":
        calculo = (quant * 1.70).toFixed(2)
        console.log(`O valor total é R$${calculo}`);
        break;
    case "101":
        calculo = (quant * 2.30).toFixed(2)
        console.log(`O valor total é R$${calculo}`);
        break;
    case "102":
        calculo = (quant * 2.60).toFixed(2)
        console.log(`O valor total é R$${calculo}`);
        break;
    case "103":
        calculo = (quant * 2.40).toFixed(2)
        console.log(`O valor total é R$${calculo}`);
        break;
    case "104":
        calculo = (quant * 2.50).toFixed(2)
        console.log(`O valor total é R$${calculo}`);
        break;
    case "105":
        calculo = (quant * 1.00).toFixed(2)
        console.log(`O valor total é R$${calculo}`);
        break;

    default:
        alert('Insira um código válido')
        break;
    }
 


