let elementoSelect = document.getElementById("slct")


function mostrarValor() {
    
 alert(elementoSelect.value)

}


let trocarPagina = document.getElementById("")

function trocaPagina(){

// window.location.href = "page2.html"
window.open("page2.html","_blank")


}