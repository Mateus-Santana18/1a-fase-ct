let numeroUm,numeroDois,numeroTres
let somaNumeros, mediaNumeros

numeroUm = Number(prompt("Digite o primeiro número: "))
numeroDois = Number(prompt("Digite o segundo número: "))
numeroTres = Number(prompt("Digite o terceiro número: "))

somaNumeros = numeroUm + numeroDois + numeroTres
mediaNumeros = somaNumeros / 3
alert("A soma é: " + somaNumeros + "\nA média é: " + mediaNumeros)
