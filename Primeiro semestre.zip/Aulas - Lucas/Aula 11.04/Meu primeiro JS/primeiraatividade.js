let numeroUm = 10
let numeroDois = 5

let idade = 67
 
    
    let nome = prompt("Digite o seu nome: ")
        alert(nome)
