let nome,idade

// nome = prompt('Digite o seu nome: ').toLowerCase()
idade = Number(prompt("Digite a sua idade: "))

// switch(nome){

//     case 'mateus':
//         alert('!!!!')
//         break;

//     case 'ta':
//         alert("????")
//         break;

//     case 'ursula':
//         alert("****")
//         break;

//     default:
//         alert("&&&&")
    
// }

switch (idade) {
    case 18:
    case 19:
    case 20:
        alert('maioridade')    
        break;

    case 17:
        alert('menoridade')
        break

    default:
        alert('sla')    
    
}