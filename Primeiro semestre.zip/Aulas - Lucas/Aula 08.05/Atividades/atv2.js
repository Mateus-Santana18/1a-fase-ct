let cor = prompt("Digite uma primária ou secundária: ").toLowerCase()

switch (cor) {
    case "vermelho":
    case "amarelo":
    case "azul":    
        alert("Cor primária!")
        break;
    
    case "verde":
    case "laranja":
    case "roxo":
        alert("Cor secundária!")
        break

    default:
        alert("Cor não primária ou secundária!")
        break;
}