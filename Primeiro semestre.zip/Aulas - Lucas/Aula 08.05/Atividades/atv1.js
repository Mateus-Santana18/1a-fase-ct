console.log('Falar com o Atendente, digite A');
console.log('Falar com o RH, digite B');
console.log('Falar com o Gerente, digite C');
console.log('Sair, digite D');

Menu()


function Menu(){
    
    let user = prompt("Digite qual sua operação: ").toLowerCase()
    
    switch (user) {
        case "a":
            alert('Direcionando para o atendente.....')
                Menu()
            break;   

        case "b":
            alert('Direcionando para o RH....')
                Menu()
            break     

        case "c":
            alert('Direcionando para o gerente....')
                Menu()
            break     

        case "d":
            alert('Saindo.....')
            break;
        
            default:
            alert('Selecione uma opção válida!')
                Menu()
                

    }
}

