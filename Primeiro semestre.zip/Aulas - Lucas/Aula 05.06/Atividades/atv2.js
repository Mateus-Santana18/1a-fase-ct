// SCRUM é uma metodologia ágil de gerenciamento de projetos muito utilizada na área da tecnologia. Dentro do SCRUM,
// o planejamento é realizado através de 'sprints' que normalmente variam de 15 a 30 dias. 
// Criar um programa onde o usuário deve digitar o tempo total do projeto em dias e o período das sprints. 
// Após calculado o número de sprints (média), arredondando o número para baixo,
// cadastrar para cada sprint um título e um objetivo.

let tempo = Number(prompt("Digite o tempo total do projeto: "))
let sprint = Number(prompt("Digite o total de sprints do projeto: "))

let calculoSprints = tempo / sprint
calculoSprints = Math.trunc(calculoSprints)
let resultado = ''
let objetivo
let titulo
for(i = 0; i < calculoSprints; i++) {
    
    titulo = prompt("Digite o titulo da sprint: ")
    objetivo = prompt("Digite o objetivo da sprint: ")
    resultado = resultado + `Sprint ${i}\nTítulo: ${titulo}\nObjetivo: ${objetivo}\n`

}

alert(resultado)