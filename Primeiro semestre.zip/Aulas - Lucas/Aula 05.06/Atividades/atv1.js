 let cidade = prompt("Digite a cidade: ")

let dia = 5
let resultado = ''
let soma = 0
let maiorTemperatura = 0
let menorTemperatura = 9999
let calculoMedia = 0
let ampliDia

for(i = 0; i < dia; i++) {
    
    let tempMaior = Number(prompt("Digite a maior temperatura de hoje: "))
    let tempMenor = Number(prompt("Digite a menor temperatura hoje:"))
    
    

    if (tempMaior >= maiorTemperatura) {
        maiorTemperatura = tempMaior
        
    }if (tempMenor <= menorTemperatura) {
        menorTemperatura = tempMenor
        
    }

    
    ampliDia = tempMaior - tempMenor
    soma = soma + ampliDia
    resultado = resultado + `Amplitude do dia ${i+1}: ${ampliDia}°\n`
}

    calculoMedia = soma / 5

alert(`As amplitudes foram ${resultado}`)
alert(`A média da temperatura semanal foi ${calculoMedia}`)
alert(`A maior temperatura registrada na semana foi ${maiorTemperatura}°, a menor temperatura foi ${menorTemperatura}°`)