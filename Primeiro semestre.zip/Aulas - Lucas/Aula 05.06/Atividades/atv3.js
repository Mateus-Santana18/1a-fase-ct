let numeroJogador = Number(prompt("Digite a quantidade de jogadores: "))
let jogadas
let somaRodada = 0
let resultado = `Pontuação TOTAL:\n`

for(i = 0; i < numeroJogador; i++){

    for(j = 0; j < 4; j++ ){
        
        do{
            
            jogadas = Number(prompt(`Digite a pontuação da rodada ${j+1} do jogador ${i+1}: `))

            if (jogadas < 1 || jogadas > 20) {
                
                alert("Valor inválido!!")

            }
        
        }while(jogadas < 1 || jogadas > 20)


        if (j == 1 || j == 2) {
            
            somaRodada = somaRodada + jogadas

        }
        
    }

    resultado = resultado + `Jogador ${i+1} fez no total ${somaRodada} pontos.\n`

    somaRodada = 0

}

alert(resultado)