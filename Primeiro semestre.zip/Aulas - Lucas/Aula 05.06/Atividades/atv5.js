let capacidadeRestaurante = 50
let ocupacaoRestaurante = 0
let ocupacaoRestante
let insumo = 'ok'

while(ocupacaoRestaurante < capacidadeRestaurante && insumo != 'insuficientes'){

    ocupacaoRestante = Number(prompt("Quantas pessoas reservaram agora? ")) 

    ocupacaoRestaurante += ocupacaoRestante

    insumo = prompt("Insumos suficientes? ")

}

    if(insumo == 'insuficientes' && capacidadeRestaurante < 50) {
      
        alert("O restaurante encerrou o atendimento devido aos insumos insuficientes!!")

    }else if(capacidadeRestaurante >= 50 && insumo == 'ok'){

        alert("O restaurante encerrou o atendimento devido a super lotação!!")        

    }else{
        
        alert("O restaurante encerrou o atendimento devido a super lotação e insumos insuficientes!!")

    }
