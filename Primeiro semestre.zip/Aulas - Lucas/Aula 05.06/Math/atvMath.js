let notaUm, notaDois, notaTres, notaQuatro

for(i = 0; i < 4; i++){

 notaUm = Math.floor(Math.random() * (11 - 0) + 0) 
 notaDois = Math.floor(Math.random() * (11 - 0) + 0) 
 notaTres = Math.floor(Math.random() * (11 - 0) + 0) 
 notaQuatro = Math.floor(Math.random() * (11 - 0) + 0) 

}
let media = (notaUm + notaDois + notaTres + notaQuatro) / 4

alert(`Primeira nota: ${notaUm}\nSegunda nota: ${notaDois}\nTerceira nota: ${notaTres}\nQuarta nota: ${notaQuatro}\n\nA média foi: ${media}`)


