// Math.ceil : Arredonda para cima.
// Math.floor : Arredonda para baixo.
// Math.round : Arredonda para o mais próximo, 2.6 : arredonda para cima; 2.4 : arredonda para baixo.
// Math.trunc : Arredonda para o próprio número, retirando os números após a virgula.
// Math.max : Retorna o maior número dentre um conjunto.
// Math.min : Retorna o maior número dentre um conjunto.
// Math.abs : Arredonda o número para positivo.
// Math.pow : Retorna calculo de exponenciação.
// Math.sqrt : Retorna a raiz quadrada.
// Math.cbrt : Retorna a raiz cubica.
// Math.random : Retorna números aleatórios.

for(i = 0; i < 100; i++){

    // let numero = Math.floor(Math.random() * max) Retornara números entre 0 e 1 multiplicados por um número MAX
    // let numero = Math.floor(Math.random() * (max - min) + min) Retornara números entre o número abaixo do MAX e o número MIN
    console.log(numero);

}

// let numero = Math.sqrt(64)
// let numeroDois = Math.cbrt(64)

// let base = 2, expoente = 4
// let resultado
// resultado = Math.pow(base,expoente)
// alert(resultado)

// let numero = 3.2
// numero = Math.ceil(numero)
// alert(numero)