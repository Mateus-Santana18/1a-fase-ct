let saldo = 1000
let conta
let contaDepositada

repetir()

function repetir() {
    let operacao = Number(prompt("1) Saldo\n 2) Depósito\n 3) Saque\n 4) Sair"))

    switch(operacao){

        case 1:
                console.log(`R$${saldo.toFixed(2)}`);
                    repetir()
        break
        case 2:
            let deposito = Number(prompt('Digite o quanto deseja depositar: R$'))
                contaDepositada = saldo + deposito
                console.log(`Seu saldo após esse depósito é R$${contaDepositada.toFixed(2)}`);
                    repetir() 
                
        break
        case 3:
            let saque = Number(prompt('Digite o quanto deseja sacar: R$'))
                if(saque <= contaDepositada || saque <= saldo){
                    conta = contaDepositada - saque
                    console.log(`Seu saldo após o saque é R$${conta}`);
                }else{
                    alert('Saldo indisponivel!!!')
                }
                repetir()
                    
                   
        break
        case 4:
            alert('Saindo......')
        break
        default:
            alert("Digite um código valido")
                    repetir()
}
}