    let mesAno = prompt('Digite o mês que queira verificar os dias:')

    switch(mesAno){

        case '1':
            console.log('O mês de janeiro possui 31 dias');
        break
        case '2':
            console.log('O mês de fevereiro possui 28 dias');
        break
        case '3':
            console.log('O mês de março possui 31 dias');
        break
        case '4':
            console.log('O mês de abril possui 30 dias');
        break
        case '5':
            console.log('O mês de maio possui 31 dias');
        break
        case '6':
            console.log('O mês de junho possui 30 dias');
        break
        case '7':
            console.log('O mês de julho possui 31 dias');
        break
        case '8':
            console.log('O mês de agosto possui 31 dias');
        break
        case '9':
            console.log('O mês de setembro possui 30 dias');
        break
        case '10':
            console.log('O mês de outubro possui 31 dias');
        break
        case '11':
            console.log('O mês de novembro possui 30 dias');
        break
        case '12':
            console.log('O mês de dezembro possui 31 dias');
        break
        default:
            alert('Mês inválido!!!')
        
    }