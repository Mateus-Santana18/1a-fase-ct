    let frete = 12.50
    let calculo,calculoTotal
    let valorCompra = Number(prompt('Digite o valor total da compra: R$'))
    let assinante = Number(prompt(`Digite de acordo com sua assinatura:\n1) Assinante Premium\n2) Assinante Gold\n3) Assinante Silver\n4) Não assinante`))

    switch(assinante){

        case 1:
            calculo = (valorCompra * 20) / 100
            calculoTotal = valorCompra - calculo
                console.log(`O valor total da compra é R$${calculoTotal.toFixed(2)} com desconto de R$${calculo.toFixed(2)}`);
        break
        case 2:
            calculo = (valorCompra * 20) / 100
            calculoTotal = valorCompra - calculo + frete
                console.log(`O valor total da compra é R$${calculoTotal.toFixed(2)} com desconto de R$${calculo.toFixed(2)}`);
        break
        case 3:
            calculo = (valorCompra * 10) / 100
            calculoTotal = valorCompra - calculo + frete
                console.log(`O valor total da compra é R$${calculoTotal.toFixed(2)} com desconto de R$${calculo.toFixed(2)}`);
        break
        case 4:
            
            calculoTotal = valorCompra + frete
                console.log(`O valor total da compra é R$${calculoTotal.toFixed(2)}`);
        break
        default:
            alert('Insira um código válido!!!')


    }