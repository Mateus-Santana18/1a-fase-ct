let arremessoUm = Number(prompt('Digite quantos pontos fez no primeiro arremesso:'))
let arremessoDois = Number(prompt('Digite quantos pontos fez no segundo arremesso:'))
let arremessoTres = Number(prompt('Digite quantos pontos fez no terceiro arremesso:'))

let calculo = arremessoUm + arremessoDois + arremessoTres

if(calculo <= 15 && calculo >= 0){
switch(true){

    case calculo == 15:
        alert('Deus da peteca')
    break
    case calculo <= 14 && calculo >= 10:
        alert('Petequeiro profissa')
    break
    case calculo <= 9 && calculo >= 5:
        alert('Petequeiro de final de semana')
    break
    case calculo <= 4 && calculo >= 1:
        alert('Pseudo-Petequeiro')
    break
    case calculo == 0:
        alert('Nunca petequeiro')
    break

}
}else{
    alert('Pontuação inválida!!')
}