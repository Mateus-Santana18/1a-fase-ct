let numeros

for(i = 0; i < numeros.length; i++){


    
}