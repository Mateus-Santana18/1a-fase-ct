let numero = []
let numeroAdd
let maiorNumero = 0
let somaTotal = 0

for(i = 0; i < 5; i++){

    numeroAdd = Number(prompt('Digite o número que deseja adicionar ao vetor:'))
    numero.push(numeroAdd)

    if (numeroAdd >= numeroMaior) {
        maiorNumero = numeroAdd
    }

}

for(j = 0; numero.length; j++){

    if(numero[i] != numeroMaior){

        somaTotal += numero[i] * numeroMaior

    }

}

alert(`Vetor: ${numero}\nMaior: ${numeroMaior}\nSoma: ${somaTotal}`)



// Método Splice

// for(j = 0; numeros.length; j++){

//     if(numeros[i] == numeroMaior){

//         indiceMaior = i

//     }

// }

// numeros.splice(indiceMaior, 1)

// for(i = 0; i < numeros.length; i++){

//     somaTotal += numeros[i] * numeroMaior

// }

// alert(`Vetor: ${numeros}\nMaior: ${numeroMaior}\nSoma: ${somaTotal}`)

// let numeros = []
// let pergunta
// let maiorNumero 
// let soma = 0
// let somaTodos = 0
// let multiplicacao = []

// for(i = 0; i < 5; i++){

//     pergunta = Number(prompt("Digite um número: "))
//     numeros.push(pergunta)

// }



// function compararNumeros(a, b) {
//     return a - b
// }

// maiorNumero = numeros.sort(compararNumeros)

// for(j = 0; j < numeros.length; j++){

//  somaTotal += numeros[i] * numeros[numeros.length-1]

// }

// alert(`A soma de todas as multiplicações é ${somaTodos}\nA soma de cada multiplicação é ${multiplicacao}\n`)

