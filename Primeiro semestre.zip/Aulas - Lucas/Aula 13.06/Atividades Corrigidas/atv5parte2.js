let vetorNumeros 
let numeroAdd
let j
let palindromoOk = true



    numeroAdd = prompt("Digite um número:")
    
    vetorNumeros = numeroAdd.split("")



j = vetorNumeros.length-1


for(i = 0; i < vetorNumeros.length / 2; i++){

    if(vetorNumeros[i] != vetorNumeros[j]){

        palindromoOk = false
        
    }

    j--

}

if(!palindromoOk){

    alert("Não é palíndromo!!")

}else{

    alert("É um palíndromo!!")

}
