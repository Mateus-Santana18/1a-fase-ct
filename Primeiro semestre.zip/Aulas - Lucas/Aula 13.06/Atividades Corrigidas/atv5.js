let numero = []
let numeroAdd
let j
let palindromoOk = true

for(i = 0; i < 6; i++){

    numeroAdd = Number(prompt("Digite um número:"))
    numero.push(numeroAdd)

}

j = numero.length-1


for(i = 0; i < numero.length / 2; i++){

    if(numero[i] != numero[j]){

        palindromoOk = false
        
    }

    j--

}

if(!palindromoOk){

    alert("Não é palíndromo!!")

}else{

    alert("É um palíndromo!!")

}
