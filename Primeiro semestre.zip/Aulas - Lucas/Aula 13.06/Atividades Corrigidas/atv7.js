let opEscolhida
let vetorNomes = []
let nomeAdd,pesquisarNome, excluirNome, editarNome, nomeNovo
let posicaoNome
do{

    opEscolhida = Number(prompt(`1- Cadastrar nome\n2- Excluir um nome\n3- Editar um nome\n4- Pesquisar se um nome está cadastrado\n5- Listar todos os nomes cadastrados\n0- Sair do programa\n`))
    
    switch(opEscolhida){

        case 0:
    
            alert("Saindo.....")
        break
        case 1:
            nomeAdd = prompt("Digite um nome:")
            vetorNomes.push(nomeAdd)
            alert("Cadastro realizado!!!")
        break
        case 2:
            excluirNome = prompt("Digite um nome para excluir:")
            posicaoNome = vetorNomes.indexOf(excluirNome)
            vetorNomes.splice(posicaoNome, 1)
            alert("Excluido!!")
        break
        case 3:
            editarNome = prompt("Digite um nome para excluir:")
            nomeNovo = prompt("Digite um nome para adicionar:")
            posicaoNome = vetorNomes.indexOf(editarNome)
            vetorNomes.splice(posicaoNome, 1, nomeNovo)
            // vetorNomes[posicaoNome] = nomeNovo : editar um pelo outro OBS: é melhor para o usuário
            alert("Editado")
        break
        case 4:
    
            pesquisarNome = prompt("Digite um nome para pesquisar:")

            if(vetorNomes.includes(pesquisarNome)){

                alert("Este nome está cadastrado!!!")
            
            }else{

                alert("Nome não cadastrado!!!")

            }

        break
        case 5:
    
            alert(`>>>>>Nomes cadastrados<<<<<\n\n${vetorNomes}`)

        break
    
        default:
            alert("Opção inválida!!!")
    
    }
}while(opEscolhida != 0)

