let palindromo = []
let numero

for(i = 0; i < 6; i++){

    numero = prompt("Digite um número:")
    palindromo.push(numero)


}

if(palindromo.length % 2 == 0 ){

    const firstPart = palindromo.slice(0, (palindromo.length / 2) ).join("")
    const secondPart = palindromo.slice(palindromo.length / 2, (palindromo.length)).reverse().join("")
    console.log(firstPart);
    console.log(secondPart);
    if(firstPart == secondPart){
        
        alert(`Palíndromo: ${palindromo}`)

    }else{

        alert("Seu número não é um palíndromo")
        
    }

}


    


