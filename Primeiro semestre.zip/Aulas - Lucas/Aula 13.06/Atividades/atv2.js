let alistamento = []
let alistPesquisa
let ano = 2000
let ultimoAno


for(i = ano; i < 2010; i++){

    alistPesquisa = prompt(`Digite se houve alistamento no ano ${i}`)
    alistamento.push(alistPesquisa)

}


    ultimoAno = alistamento.lastIndexOf("S")

    if(ultimoAno == -1){
        alert("Não houve alistamento nos ultimos 10 anos")
    }else{
        alert(`O ultimo ano que houve alistamento foi 200${ultimoAno}`)
    }