let numeros = []
let pergunta
let maiorNumero 
let soma = 0
let somaTodos = 0
let multiplicacao = []

for(i = 0; i < 5; i++){

    pergunta = Number(prompt("Digite um número: "))
    numeros.push(pergunta)

}



function compararNumeros(a, b) {
    return a - b
}

maiorNumero = numeros.sort(compararNumeros)

for(j = 0; j < numeros.length; j++){

    if (j < 4) {
        soma = numeros[j] * numeros[4]
        somaTodos += soma
        multiplicacao.push(soma) 
    }

}

alert(`A soma de todas as multiplicações é ${somaTodos}\nA soma de cada multiplicação é ${multiplicacao}\n`)