let produto = []
let precoArray = []
let nomeProdutos = 'Os nomes dos produtos de 50 a 100 são\n'
let productSearch, priceSearch
let quantidade = 0  , mediaProdutos = 0, somaProdutos = 0, contCem = 0
for(i = 0; i < 5; i++){

    productSearch = prompt("Digite o nome do produto: ")
    priceSearch = Number(prompt("Digite o preço do produto: R$"))
    produto.push(productSearch)
    precoArray.push(priceSearch)    
    


}

for (let index = 0; index < precoArray.length; index++) {
        const preco = precoArray[index]
       
    if (preco < 50) {
       quantidade++
    }
    if(preco >= 50 && preco <= 100){
        nomeProdutos += `Nome: ${produto[index]}\n`
    }
    if(preco > 100){
        somaProdutos += preco
        contCem++
    }
}

mediaProdutos = somaProdutos / contCem



alert(`A quantidade de produtos inferior a R$50 é ${quantidade }\n\n${nomeProdutos}\n\nA média dos produtos é ${mediaProdutos}`)
// 