let doencas = []
let doencasVirus = []
let doencaBacteria = []
let doencaAmbos = []

let doencasAdd = Number(prompt("Digite quantas doenças quer adicionar"))

let pergunta, causador
for(i = 0; i < doencasAdd; i++){

    pergunta = prompt("Digite o nome da doença: ")
    causador = prompt("Digite qual o causador da doença: ")
    doencas.push(pergunta)

    if(causador == "virus"){
        doencasVirus.push(pergunta)
    }

    if(causador == "bacteria"){
        doencaBacteria.push(pergunta)

    }

    if(causador == "ambos"){
        doencaAmbos.push(pergunta)

    }
    

}

alert(`Doenças: ${doencas}\n\nDoenças causadas pelo vírus: ${doencasVirus}\nDoenças causadas pela bactéria: ${doencaBacteria}\nDoenças causadas por ambos ${doencaAmbos}`)

