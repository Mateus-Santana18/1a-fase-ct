let vetor = []


console.log(">>>>> MENU <<<<<")
console.log("1- Cadastrar nome")
console.log("2- Excluir um nome")
console.log("3- Editar um nome")
console.log("4- Pesquisar se um nome está cadastrado")
console.log("5- Listar todos os nomes cadastrados")
console.log("0- Sair do programa")



function searchNames(){
let pergunta = Number(prompt("Digite qual opção deseja: "))
let excluirNome, indiceExcluir 
let editarNome, addNome
let pesquisarNome, resultado = 'Os nomes são:\n'


if(pergunta == 1){

    let perguntaNome = prompt("Digite o nome que deseja cadastrar:")
    vetor.push(perguntaNome)
    searchNames()
}

if(pergunta == 2){
    excluirNome = prompt("Digite o nome que deseja excluir: ")
for(i = 0; i < vetor.length; i++){

    
    if(excluirNome == vetor[i]){
        indiceExcluir = i
        vetor.splice(indiceExcluir, 1)
        alert("Nome excluído do nosso sistema com sucesso!!")
    }else{
        alert("Este nome não está cadastrado, impossivel exclui-lo")
    }
    

}
searchNames()
}

if(pergunta == 3){
    editarNome = prompt("Digite o nome que deseja editar: ")
    for(i = 0; i < vetor.length; i++){

    
        if(editarNome == vetor[i]){
            indiceExcluir = i
            vetor.splice(indiceExcluir, 1)
        }
    
    }

    addNome = prompt("Digite o nome correto: ")
    vetor.splice(indiceExcluir, 1, addNome)
    searchNames()
}

if(pergunta == 4){

    pesquisarNome = prompt("Digite um nome para pesquisar: ")

        if (vetor.includes(pesquisarNome)) {
            alert("Este nome está cadastrado no nosso sistema!!!!")
        }else{
            alert("Este nome não possui registro no nosso sitema!!!!")
        }

        searchNames()
}

if(pergunta == 5){

    vetor.forEach(element => console.log(element))
    alert(`${resultado} ${vetor}`)
    searchNames()
}

if(pergunta == 0){

    alert("Encerrando Programa!!!!")

}
}
searchNames()