//                 0           1        2        3  
let cidades = ['bruxelas', 'berlim', 'praga', 'viena', 'budapeste']
let distancia = [0, 764, 350, 292, 242]
let origem, destino, distanciaTotal = 0 
let posOrigem, posDestino

    origem = prompt("Digite sua origem:")
    destino = prompt("Digite seu destino:")

    posOrigem = cidades.indexOf(origem)
    posDestino = cidades.indexOf(destino)

for(i = posOrigem; i <= posDestino; i++){

    distanciaTotal += distancia[i]

}

alert(`Distância total: ${distanciaTotal}km²`)