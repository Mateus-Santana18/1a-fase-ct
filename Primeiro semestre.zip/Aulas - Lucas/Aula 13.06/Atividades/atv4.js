let vetorUm = []
let vetorDois = []
let vetorTres = []
let corPrimaria, corSecundaria

for(i = 0; i < 3; i++){

    corPrimaria = prompt("Digite uma cor primária:")
    vetorUm.push(corPrimaria)
    
    

}
vetorTres.push(vetorUm)

for(i = 0; i < 3; i++){

    corSecundaria = prompt("Digite uma cor secundária: ")
    vetorDois.push(corSecundaria)

}
vetorTres.push(vetorDois)




let pergunta = prompt("Digite uma cor que deseja adicionar no ínicio: ")
vetorTres.splice(0, 0, pergunta)

let perguntaDois = prompt("Digite uma cor que deseja adicionar no final: ")
vetorTres.push(perguntaDois)

alert(vetorTres)


