
let qntdUm = document.getElementById('qnt1')
let qntdDois = document.getElementById('qnt2')
let qntdTres = document.getElementById('qnt3')
let qntdQuatro = document.getElementById('qnt4')
let valorUm = document.getElementById('valor1')
let valorDois = document.getElementById('valor2')
let valorTres = document.getElementById('valor3')
let valorQuatro = document.getElementById('valor4')
let divResultado = document.getElementById('resultado')
let descontoProduto = document.getElementById('desconto')
let descontoMostrado = document.getElementById('descontoMostrar')
let conta1,conta2,conta3,conta4,resultadoSoma,descontoInicial


function Calcular() {
    conta1 = Number((qntdUm.value) * Number(valorUm.value)) + (Number(qntdDois.value) * Number(valorDois.value)) + (Number(qntdTres.value) * Number(valorTres.value)) + (Number(qntdQuatro.value) * Number(valorQuatro.value))
    // conta2 = Number(qntdDois.value) * Number(valorDois.value)
    // conta3 = Number(qntdTres.value) * Number(valorTres.value)
    // conta4 = Number(qntdQuatro.value) * Number(valorQuatro.value)
    // resultadoSoma = conta1 + conta2 + conta3 + conta4
    descontoInicial = Number(conta1) * Number(descontoProduto.value) / 100
    resultadoSoma = conta1 - descontoInicial
    descontoMostrado.innerHTML = Number(descontoInicial).toFixed(2)
    divResultado.innerHTML = Number(resultadoSoma).toFixed(2)

//     if(descontoInicial > 0){
//         conta1 = Number((qntdUm.value) * Number(valorUm.value)) + (Number(qntdDois.value) * Number(valorDois.value)) + (Number(qntdTres.value) * Number(valorTres.value)) + (Number(qntdQuatro.value) * Number(valorQuatro.value))
//         descontoInicial = Number(conta1) * Number(descontoProduto.value) / 100
//         resultadoSoma = conta1 - descontoInicial
//         divResultado.innerHTML = Number(resultadoSoma).toFixed(2)  
//     }
    
//     else{   
//         conta1 = Number((qntdUm.value) * Number(valorUm.value)) + (Number(qntdDois.value) * Number(valorDois.value)) + (Number(qntdTres.value) * Number(valorTres.value)) + (Number(qntdQuatro.value) * Number(valorQuatro.value))
//         divResultado.innerHTML = Number(resultadoSoma).toFixed(2)
// }
}