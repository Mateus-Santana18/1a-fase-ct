let valorUm = document.getElementById("numUm")
let valorDois = document.getElementById("numDois")
//let resultado = document.getElementById("resConta")
let divResultado = document.getElementById("resultado")

function Soma() {
    divResultado.innerHTML = (Number(valorUm.value) + Number(valorDois.value)).toFixed(2)
    //document.getElementById("resultado").innerHTML = (Number(valorUm.value) + Number(valorDois.value)).toFixed(2)
    //resultado.value = Number(resultado.value).toFixed(2)
}
function Subtracao() {
    divResultado.innerHTML = (Number(valorUm.value) - Number(valorDois.value)).toFixed(2)
    //resultado.value = (Number(valorUm.value) - Number(valorDois.value)).toFixed(2)
    // resultado.value = Number(resultado.value).toFixed(2)
}
function Multiplicacao() {
    divResultado.innerHTML = (Number(valorUm.value) * Number(valorDois.value)).toFixed(2)
    //resultado.value = (Number(valorUm.value) * Number(valorDois.value)).toFixed(2)
    // resultado.value = Number(resultado.value).toFixed(2)
}
function Divisao() {
    divResultado.innerHTML = (Number(valorUm.value) / Number(valorDois.value)).toFixed(2)
    //resultado.value = (Number(valorUm.value) / Number(valorDois.value)).toFixed(2)
    // resultado.value = Number(resultado.value).toFixed(2)
}

function Limpar() {
    valorUm.value = ''
    valorDois.value = ''
    resultado.value = ''
}


