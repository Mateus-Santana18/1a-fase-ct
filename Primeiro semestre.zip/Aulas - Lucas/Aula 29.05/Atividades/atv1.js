let paisA = 80000
let paisB = 200000

let taxaA = 0.03
let taxaB = 0.015

let anosFaltam = 0

while (paisA < paisB){
    
    paisA = paisA + (paisA * taxaA)

    paisB = paisB + (paisB * taxaB)

    anosFaltam = anosFaltam + 1

}
alert(`Para o país A ultrapassar a população do país B será necessário ${anosFaltam} anos.`)