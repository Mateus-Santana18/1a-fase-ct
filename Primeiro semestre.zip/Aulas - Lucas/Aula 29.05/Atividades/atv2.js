/* Os números primos possuem várias aplicações dentro da Computação, por exemplo, na criptografia. Um número primo é aquele que é divisível apenas por um e por ele mesmo. Faça um programa que peça ao usuário para digitar cinco números inteiros e mostre na tela se são primos ou não. */

let numero
let cont = 2, contNum = 0
let flag = false
let resultado = ''

    while(contNum < 5){

        numero = Number(prompt("Digite um número: "))
    
        while(cont < numero){
    
           if(numero % cont == 0){
    
                flag = true
            
           }
    
           cont++
           
        }

        cont = 2
        
        if(flag || numero == 1){
           
            resultado = resultado + `${numero} -> não é primo!\n`
            flag = false
           
        }else{
           
            resultado = resultado + `${numero} -> é primo!\n`
           
        }

        contNum++

    }

alert(resultado)

