let nomeMaisCaro
let nomeMaisBarato
let dinheiroTotal = 200
let totalGasto = 0
let valorVinil
let nomeVinil
let soma = 0
let resultado = ''
let sobra
let i = 0
let mediaVinil
let maisCaro = 0
let maisBarato = 9999


while (soma < dinheiroTotal){

    

    nomeVinil = prompt("Digite o nome do vinil: ")
    valorVinil = Number(prompt("Digite o valor do vinil: "))
    if(totalGasto + valorVinil >= 200){
        break;
    } 
    
    soma = soma + valorVinil
    resultado = resultado + nomeVinil
    sobra = dinheiroTotal - soma

            if (valorVinil >= maisCaro) {
                maisCaro = valorVinil
                nomeMaisCaro = nomeVinil
            }if(valorVinil <= maisBarato){
                maisBarato = valorVinil
                nomeMaisBarato = nomeVinil
            }
        
        

        i++

}

mediaVinil = soma / i

alert(`O total gasto foi de R$${soma}\nO valor que sobrou foi R$${sobra}\nAo total foram comprados ${i} vinis\nA média dos preços dos vinis é R$${mediaVinil}`)
alert(`O vinil ${nomeMaisCaro} foi R$${maisCaro}\n\nO vinil ${nomeMaisBarato} R$${maisBarato}`)



