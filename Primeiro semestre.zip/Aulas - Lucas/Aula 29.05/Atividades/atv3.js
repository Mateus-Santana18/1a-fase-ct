let numero = Number(prompt("Digite um número:"))
let i = 1
let eprimo = true
let resultado
while (i < numero) {
    i++
    eprimo = true
    let j = 2
    console.log('while: j ' + j + ' i '+i);
    while (j < i && eprimo == true) {
        
        console.log('if: j ' + j + ' i '+i);
        if (i % j == 0) {
            eprimo = false

        }
        j++
    }

    if (eprimo == true) {
        alert(i + ' eh primo, porr@')
    }
}


