let jogador1 = prompt("digite seu nome:")
let jogador2 = prompt("digite seu nome:")

let cont = 0
let soma1 = 0
let soma2 = 0

while(cont < 10){
jogada1 = Number(prompt(`digite as cartas do ${jogador1}`))
if(jogada1 <1 || jogada1>13){
alert("carta errada")
}else{
soma1 = soma1 + jogada1
}
cont++

jogada2 = Number(prompt(`digite as cartas do ${jogador2}`))
if(jogada2 <1 || jogada2>13){
alert("carta errada")
}else{
soma2 = soma2 + jogada2
}
cont++

}
alert(`${jogador1} fez ${soma1} pontos ${jogador2} fez ${soma2} pontos`)

if(soma1 > soma2){
alert(`${jogador1} ganhou`)
}else{
if(soma2 > soma1){
alert(`${jogador2} ganhou`)
}else{
alert(`empate`)
}
}