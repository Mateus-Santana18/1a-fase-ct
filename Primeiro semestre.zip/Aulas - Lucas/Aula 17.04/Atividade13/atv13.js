let largura = Number(prompt("Digite qual a largura da sua piscina:"))
let comprimento = Number(prompt("Digite o comprimento da piscina:"))

let calculo = (comprimento * largura) * 120
let calculoCaixa = (calculo / 60).toFixed()
let calculoPreco = calculo / 60 * 45.50

alert(`Para a sua piscina será necessário ${calculoCaixa} caixas de azulejos e será ${calculo} azulejos \nNo total pagará R$${calculoPreco.toFixed(2)} pelos azulejos`)