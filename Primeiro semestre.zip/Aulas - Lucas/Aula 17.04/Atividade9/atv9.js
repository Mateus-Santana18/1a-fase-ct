let pesoUm = 1
let pesoTres = 3

let notaUm = Number(prompt("Digite a sua primeira nota:"))
let notaDois = Number(prompt("Digite a sua segunda nota:"))
let notaTres = Number(prompt("Digite a sua terceira nota:"))

let calculo = ((notaUm * pesoUm) + (notaDois * pesoUm) + (notaTres * pesoTres)) / (pesoUm + pesoUm + pesoTres)


alert(`O calculo da média é ${calculo.toFixed(2)}`)
