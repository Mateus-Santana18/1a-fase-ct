let base = Number(prompt("Digite a base"))
let exp = Number(prompt("Digite o seu expoente:"))

let calculo = base ** exp

alert(`O a exponenciação da base ${base} e o seu expoente ${exp} é ${calculo} `)