let peso = Number(prompt("Digite o seu peso: "))
let altura = Number(prompt("Digite a sua altura:"))

let imc = peso / (altura * altura)
imc = imc.toFixed(3)

alert(`O resultado do IMC é de ${imc}`)