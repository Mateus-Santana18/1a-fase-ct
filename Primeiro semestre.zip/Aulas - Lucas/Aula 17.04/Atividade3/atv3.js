let distancia = Number(prompt("Digite a distância percorrida:"))
let tempo = Number(prompt("Digite quanto tempo durou a trilha:"))

let resultado = distancia / tempo

alert(`Sua média de velocidade durante essa trilha foi de ${resultado} km/h`)