let tempC = Number(prompt("Digite a temperatura em Celsius:"))

let tempF2 = Number(((tempC * 9/5) + 32)).toFixed(2)
let tempF = tempC * 1.8 + 32

alert(`A temperatura em graus Celsius é ${tempC}* e em Fahrenheit é ${tempF}*`)
alert(`A temperatura em graus Celsius é ${tempC}* e em Fahrenheit é ${tempF2}*`)
