let eleitores = Number(prompt("Digite o número de eleitores:"))
let candidatoX = Number(prompt("Digite o numero de votos do candidato X:"))
let candidatoY = Number(prompt("Digite o numero de votos do candidato Y:"))
let branco = Number(prompt("Digite o numero de votos em branco:"))
let nulo = Number(prompt("Digite o numero de votos nulos"))

let votosTotais = candidatoX + candidatoY + branco + nulo
let percentualX = candidatoX * 100 / votosTotais    
let percentualY = candidatoY * 100 / votosTotais
let percentualB = branco * 100 / votosTotais
let percentualN = nulo * 100 / votosTotais

alert(`O total de votos é ${votosTotais}, o percentual do candidato X é ${percentualX}%, o percentual do candidato Y é ${percentualY}%, o total do percentual em branco é ${percentualB}% e o percentual nulo é ${percentualN}%`)



