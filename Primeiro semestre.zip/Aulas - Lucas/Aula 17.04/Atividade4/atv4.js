let semana = 52
let dias = 365
let meses = 12
let anos
let anoAtual = Number(prompt("Digite o ano atual:"))
let anoNascimento = Number(prompt('Digite o ano que você nasceu'))


anos = anoAtual - anoNascimento
meses = anos * meses
semana = anos * semana
dias = anos * dias

alert(`A sua idade é: ${anos} anos, ${meses} meses, ${semana} semanas e ${dias} dias `)