let macho = 5
let femea = 9
let areaCasal = 400
let areaSolteiro = 320
let casal = Number(prompt("Digite quantos casais de leões baios:"))

let solteiro = femea + macho - casal*2

let areaTotal = (solteiro * areaSolteiro) + (casal * areaCasal)



alert(`O total de casais é de ${casal} e ocupam uma área de ${areaTotal}KM²`)