function enviar() {
    

let nome = document.getElementById('nome_inserir')  //(prompt('Digite o seu nome:'))
let idade = document.getElementById('idade_inserir') //(prompt('Digite a sua idade:'))
let nacionalidade = document.getElementById('nacio_inserir')  //(prompt('Digite sua nacionalidade:'))
let endereco = document.getElementById('endereco_inserir')  //(prompt('Digite o seu endereço:'))
}

//alert(`Cliente ${nome}, com idade ${idade} anos,${nacionalidade}, reside no endereço: ${endereco}`)