let numeroUm = Number(prompt("Digite 1 número:"))
let numeroDois = Number(prompt('Digite outro número: '))
let resultado = numeroUm * numeroDois

alert(`O resultado da multiplicação do numero ${numeroUm} e do numero ${numeroDois} é ${resultado}`)

