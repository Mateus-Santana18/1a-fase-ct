// Em uma fábrica de reciclagem de materiais, cada 10kg de plástico rendem R$2,00 cada 
// 30kg de papel rendem R$3,00 e cada 50kg de metal rendem R$5,00. Perguntar ao usuário a quantidade (kg) 
// de cada material que deseja entregar na fábrica e mostrar o total que receberá em reais.

let plastico = Number(prompt("Digite a quantidade de plástico que deseja entregar na fabrica"))
let papel = Number(prompt("Digite a quantidade de papel que deseja entregar na fabrica"))
let metal = Number(prompt("Digite a quantidade de metal que deseja entregar na fabrica"))

let calculoPlastico = plastico * 0.2
let calculoPapel = papel * 0.1
let calculoMetal = metal * 0.1
let calculoTotal = calculoPlastico + calculoPapel + calculoMetal

alert(`O preco total de ${plastico} plasticos é de R$ ${calculoPlastico.toFixed(2)}, o preço total de ${papel} KG de papéis é de R$ ${calculoPapel.toFixed(2)} e o de ${metal} KG de metais é de R$ ${calculoMetal.toFixed(2)}`)
alert("O preço total é R$" + calculoTotal.toFixed(2))