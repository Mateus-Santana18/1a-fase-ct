let numero = []
let numeroAdd
let soma = 0

for(i = 0; i < 5; i++){

    numeroAdd = Number(prompt("Digite um número"))
    numero[i]

    if (numeroAdd % 2 == 1) {
        numero.push(numeroAdd)
        soma = soma + numeroAdd
    }

}

alert(`Impares: ${numero}\nSoma: ${soma}`)