let primeiroVetor = []
let segundoVetor = []
let vetorIntercalado = []
let numeroAdd

    for(i = 0; i < 6; i++){

        numeroAdd = Number(prompt("Digite um número: "))

        if(i < 3){
            primeiroVetor.push(numeroAdd)
        }else{
            segundoVetor.push(numeroAdd)
        }

    }
    for(j = 0; j < 3; j++){

        vetorIntercalado.push(primeiroVetor[j])
        vetorIntercalado.push(segundoVetor[j])
    }

    alert(vetorIntercalado)

