let vetor = [1, 2, 3, 4, 5, 6, 7, 8, 9, 9]
let pergunta
let resultado = '>>>>Índices que o número aparece!<<<<\n\n'
let numeroEncontrado = false

    pergunta = Number(prompt("Digite um número: "))

    for(i = 0; i < vetor.length; i++){

        if(pergunta == vetor[i]){

            resultado += `Índice: ${i}\n`
            numeroEncontrado = true

        }


    }
    if (!numeroEncontrado) {
        
        resultado += `Não localizamos o número!`

    }

alert(resultado)

// OUTRA FORMA
// let vetor = [1, 2, 3, 4, 5, 6, 7, 8, 9, 9]
// let pergunta
// let vetorIndices = []


//     pergunta = Number(prompt("Digite um número: "))

//     for(i = 0; i < vetor.length; i++){

//         if(pergunta == vetor[i]){

//             vetorIndices.push(i)

//         }


//     }

// alert("Índices: " + vetorIndices)