let numerosInteiros = []
let numeroAdd
let somaPrimeira = 0
let somaSegunda = 0
let total

for(i = 0; i < 10; i++){

    numeroAdd = Number(prompt("Digite 10 números: "))
    numerosInteiros.push(numeroAdd)
    numerosInteiros[i]
    if(i < 5){
        somaPrimeira += numerosInteiros[i]
    }
    else{
        somaSegunda += numerosInteiros[i]
    }

}

total = somaPrimeira - somaSegunda

alert(`A soma do primeiro: ${somaPrimeira}\nA soma do segundo: ${somaSegunda}\nO total é ${total}`)