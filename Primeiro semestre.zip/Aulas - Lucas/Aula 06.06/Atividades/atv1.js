let numero = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

for(i = 0; i < 10; i++){

    numero.pop()

}

alert(numero)

// let numero = []

// for(i = 0; i < 15; i++){

//     numero.push(i+1)

// }

// alert(numero)