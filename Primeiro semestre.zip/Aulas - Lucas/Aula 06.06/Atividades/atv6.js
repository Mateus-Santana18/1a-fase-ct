let frutas = ["banana", "maçã"]
let frutaAdd

do{

    frutaAdd = prompt("Digite uma fruta")
    frutas.push(frutaAdd)

}while(frutaAdd != "cereja")

alert(frutas)