let numero = []
let numeroAleatorio
for(i = 0; i < 10; i++){

    numeroAleatorio = Math.floor(Math.random() * (21 - 0) + 0 )
    numero.push(numeroAleatorio)

}

alert(numero)