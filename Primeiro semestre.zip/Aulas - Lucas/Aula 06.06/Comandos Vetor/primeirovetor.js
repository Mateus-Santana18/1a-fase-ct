//              0   1   2   3
// let numeros = [2, 6, 8, 9]
// let numerosInteiros = []
// let nomes = ['Santana', 'Oliveira']
// let nomesModernos = []
// let nomeAdd

// Método push e pop, e comando length
    
//     for(i = 0; i < 4; i++){

//         nomeAdd = prompt("Digite um nome: ")
//         nomesModernos.push(nomeAdd)

//     }

//     console.log(nomesModernos.length);

// alert(nomesModernos)

//     nomesModernos.pop()
//     console.log(nomesModernos.length);

// alert(`Primeiro: ${nomesModernos[0]}\nÚltimo: ${nomesModernos[nomesModernos.length-1]}`)



// for(i = 0; i < numeros.length; i++){

//     alert(numeros[i])

// }



// Método includes()

// let vetorNumeros = [2, 6, 8, 9]
// let numeroExiste, numeroPesquisa

    // numeroPesquisa = Number(prompt("Digite um número: "))

    // numeroExiste = vetorNumeros.includes(numeroPesquisa)

    // if(numeroExiste){

    //     alert("Existe!")

    // }else{

    //     alert("Não existe!")

    // }



// Método indexOf e lastIndexOf()

// let cores = ['verde', 'amarelo', 'verde', 'roxo', 'laranja']
// let corPesquisada, primeiroIndiceCor, ultimoIndiceCor

//     corPesquisada = prompt("Digite uma cor: ")

//     primeiroIndiceCor = cores.indexOf(corPesquisada)
//     ultimoIndiceCor = cores.lastIndexOf(corPesquisada)

//     if(primeiroIndiceCor == -1){

//         alert("Cor não encontrada")

//     }else{

//         alert(`O primeiro índice da cor é: ${primeiroIndiceCor}\nO ultimo índice da cor é: ${ultimoIndiceCor}` )   
        

//     }

// Método sort()

// let idades = [10, 7, 9, 1, 14, 18, 12, 42, 30, 21]
// let nomes = ['Ursula', 'Astrogildo', 'Ermenegildo', 'Abgail']
// let idadesOrdenadas, nomesOrd

//     idadesOrdenadas = idades.sort(compararNumeros)
//     nomesOrd = nomes.sort()

// alert(idadesOrdenadas)
// alert(nomesOrd)

// function compararNumeros(a, b) {

//     return a - b

// }

// Método splice()

    // let meses = ['Jan', 'Fev', 'April', 'June']
    // meses.splice(2, 0, 'March') = adiciona no índice 2, remove 0 elementos e adiciona March.
    // alert(meses)
    // Retorna meses = ['Jan', 'Fev', 'March', 'April', 'June']

    // meses.splice(4, 1, 'May') = adiciona no índice 4, remove 1 elemento e substitui June por May.
    // alert(meses)

    // Retorna meses = ['Jan', 'Fev', 'March', 'April', 'May']


    // let cars = ['Uno', 'Parati', 'Fox', 'EcoSport', 'Fiesta']
// let carsSearch, indexCars

//     carsSearch = prompt('Digite um carro para consultar na concessionária: ')

//     for(i = 0; 0 < cars.length; i++){

//         if(carsSearch == cars[i]){

//             indexCars = i

//         }

//     }

//     cars.splice(indexCars, 1)



let carros = ['uno', 'parati', 'fox', 'ecosport', 'fiesta']
let carrosPesquisa, indiceCarros, carrosEditados

    carrosPesquisa = prompt('Digite um carro para consultar na concessionária: ')
    carrosEditados = prompt('Digite um carro para comprar na concessionária: ')

    for(i = 0; i < carros.length; i++){

        if(carrosPesquisa == carros[i]){

            indiceCarros = i

        }

    }

    carros.splice(indiceCarros, 1, carrosEditados)

   alert(carros);



    