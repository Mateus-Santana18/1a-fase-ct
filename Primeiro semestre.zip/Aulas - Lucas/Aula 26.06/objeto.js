let livro = {
    
    titulo: 'Fortaleza Digital',
    autor: 'Michael Chricton',
    editora: 'Rocco',
    paginas: 520,
    ebook: true

}

// Adicionar propriedade e valor no objeto
livro.ano = 1998

// Editando o valor de uma propriedade por que ela ja existe
livro.ebook = false

// Excluir uma propriedade e valor do objeto
delete livro.editora



// alert(livro.titulo)
// alert(Object.entries(livro))
// alert(Object.keys(livro))
alert(Object.values(livro))