let usersVector = []
let nomeAdd, senhaAdd, emailAdd
let pesquisaUsuario, posicaoUser
let dadosUser = `>>>> Dados do usuário <<<<\n\n`
let userExiste = false
let userObject = {}

for(i = 0; i < 2; i++){

    userObject = {

        nomeUsuario: '',
        senhaUsuario: '',
        emailUsuario : ''
    
    }

    nomeAdd = prompt("Digite seu nome de usuário:")
    userObject.nomeUsuario = nomeAdd

    senhaAdd = prompt("Digite sua senha:")
    userObject.senhaUsuario = senhaAdd

    emailAdd = prompt("Digite seu email:")
    userObject.emailUsuario = emailAdd

    usersVector.push(userObject)

}


pesquisaUsuario = prompt("Digite o usuário que deseja pesquisar:")

for(i = 0; i < usersVector.length; i++){

    if(pesquisaUsuario == usersVector[i].nomeUsuario){

        userExiste = true
        // posicaoUser = i
        dadosUser += Object.values(usersVector[i]).join('\n')

    }

}

if(userExiste){

    // alert(`Usuário encontrado!\n\nDados do usuário\n${Object.entries(usersVector[posicaoUser]).join('\n')}`)
    alert(dadosUser)

}else{

    alert("Usuário não encontrado!")

}



