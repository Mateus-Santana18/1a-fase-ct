let nome,idade

    nome = prompt("Digite um nome").toLowerCase()
    idade = prompt("Digite uma idade:")
    switch(true){

        case nome == 'mateus' && idade > 60:

        alert("AAAAAAAA velho")
        break

    default:
        alert("!!!!!!!")

    }

    

    