

let data = prompt("Digite sua data de nascimento: ")

switch (true){

    case data >= 0 && data <= 1945 :
        alert('Sem geração')
        break

    case data >= 1946 && data <= 1964:
        alert("Baby Boomers")
        break

    case data >= 1965 && data <= 1980:
        alert("Geração X")
        break
    
    case data >= 1981 && data <= 1996:
        alert("Geração Y ou Millennials")
        break
    
    case data >= 1997 && data <= 2010:
        alert("Geração Z")
        break
    
    case data >= 2011:
        alert("Geração alfa")
        break
    
    default:
        alert("Insira uma data válida!")
        
}