let inputResultado = document.getElementById('inptRes')
let selectNumeros = document.getElementById('slct')
let labelResultado = document.getElementById('lblRes')

function traduzNumero() {
    
    switch(selectNumeros.value){

        case 'Empty':
           
            labelResultado.innerHTML = "<br>" + "Nenhuma opção escolhida!" + "<br><br>"
        
        break

        case 'One':
           
            inputResultado.value = "Um"
            labelResultado.innerHTML = ""
        
        break
        
        case 'Two':
           
            inputResultado.value = "Dois"
            labelResultado.innerHTML = ""
        
        break
        
        case 'Three':
           
            inputResultado.value = "Três"
            labelResultado.innerHTML = ""
        
        break
        
        case 'Four':
           
            inputResultado.value = "Quatro"
            labelResultado.innerHTML = ""
        
        break
        
        case 'Five':
           
            inputResultado.value = "Cinco"
            labelResultado.innerHTML = ""
        
        break

       


    }

}