let resultado = document.getElementById('inptResultado')
let elementoSelect = document.getElementById("slct")
let divResultado = document.getElementById("opcao")



function Traducao() {
    
   switch (true){
        case elementoSelect.value == "Um":
            divResultado.innerHTML = ""
            resultado.value = elementoSelect.value
            break
        
        case elementoSelect.value == "Dois":
            divResultado.innerHTML = ""
            resultado.value = elementoSelect.value
            break
        case elementoSelect.value == "Tres":
            divResultado.innerHTML = ""
            resultado.value = elementoSelect.value
            break
        case elementoSelect.value == "Quatro":
            divResultado.innerHTML = ""
            resultado.value = elementoSelect.value
            break
        case elementoSelect.value == "Cinco":
            divResultado.innerHTML = ""
            resultado.value = elementoSelect.value
            break

        default:
            resultado.value = ""
            divResultado.innerHTML = "Nenhuma opção escolhida!"
   }

    

}